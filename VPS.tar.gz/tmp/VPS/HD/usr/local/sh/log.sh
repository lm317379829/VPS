#!/bin/bash 
. /etc/profile
echo `date +%Y-%m-%d` 
find /var/log/apt -mtime +1 -name "*.log.*" -exec rm {} \;
find /var/log -mtime +1 -name "messages.*" -exec rm {} \;
find /var/log -mtime +1 -name "*.log.*" -exec rm {} \;
find /var/log -mtime +1 -name "debug.*" -exec rm {} \;
find /var/log -mtime +1 -name "syslog.*" -exec rm {} \;
find /var/log -mtime +1 -name "btmp.*" -exec rm {} \;
find /var/log -mtime +1 -name "wtmp.*" -exec rm {} \;

logrow=$(grep -c "" /var/log/alternatives.log)
if [ $logrow -ge 1000 ];then
    > /var/log/alternatives.log
fi

logrow=$(grep -c "" /var/log/auth.log)
if [ $logrow -ge 5000 ];then
    > /var/log/auth.log
fi

logrow=$(grep -c "" /var/log/btmp)
if [ $logrow -ge 1000 ];then
    > /var/log/btmp
fi

logrow=$(grep -c "" /var/log/daemon.log)
if [ $logrow -ge 1000 ];then
    > /var/log/daemon.log
fi

logrow=$(grep -c "" /var/log/debug)
if [ $logrow -ge 1000 ];then
    > /var/log/debug
fi

logrow=$(grep -c "" /var/log/faillog)
if [ $logrow -ge 1000 ];then
    > /var/log/faillog
fi

logrow=$(grep -c "" /var/log/dpkg.log)
if [ $logrow -ge 1000 ];then
    > /var/log/dpkg.log
fi

logrow=$(grep -c "" /var/log/kern.log)
if [ $logrow -ge 1000 ];then
    > /var/log/kern.log
fi

logrow=$(grep -c "" /var/log/lastlog)
if [ $logrow -ge 1000 ];then
    > /var/log/lastlog
fi

logrow=$(grep -c "" /var/log/messages)
if [ $logrow -ge 1000 ];then
    > /var/log/messages
fi

logrow=$(grep -c "" /var/log/syslog)
if [ $logrow -ge 1000 ];then
    > /var/log/syslog
fi

logrow=$(grep -c "" /var/log/wtmp)
if [ $logrow -ge 1000 ];then
    > /var/log/wtmp
fi

logrow=$(grep -c "" /var/log/apt/history.log)
if [ $logrow -ge 1000 ];then
    > /var/log/apt/history.log
fi

logrow=$(grep -c "" /var/log/apt/term.log)
if [ $logrow -ge 1000 ];then
    > /var/log/apt/term.log
fi

logrow=$(grep -c "" /root/.aria2c/aria2.log)
if [ $logrow -ge 1000 ];then
    > /root/.aria2c/aria2.log
fi

> /usr/local/nginx/logs/access.log
> /usr/local/nginx/logs/error.log
> /root/.aria2c/aria2.log

echo 3 > /proc/sys/vm/drop_caches
swapoff -a && swapon -a

rm /home/*.torrent
