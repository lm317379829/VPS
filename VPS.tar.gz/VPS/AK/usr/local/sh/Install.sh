#!/bin/sh
. /etc/profile
LOGTIME=$(date "+%Y-%m-%d %H:%M:%S")

wget_ver=$(wget -V | grep 'built on linux-gnu')
if [ ! -n "$wget_ver" ]; then
apt-get update >/dev/null 2>&1
apt-get install wget -y >/dev/null 2>&1
fi

aria2_bit=i386
xray_bit=32
rclone_bit=386
status_bit=386
alist_bit=386

get_VPS_file()
    {
        mkdir -p /usr/local/sh
        wget --no-check-certificate -qO- "https://raw.githubusercontent.com/lm317379829/VPS/main/VPS.tar.gz"  -O '/tmp/VPS.tar.gz'
        mkdir -p /tmp/VPS/
        tar -xzvf /tmp/VPS.tar.gz -C /tmp/VPS/ >/dev/null 2>&1
}

del_VPS_file()
    {
        rm /tmp/VPS.tar.gz
        rm -r /tmp/VPS/
        apt-get autoclean -y >/dev/null 2>&1
        apt-get clean -y >/dev/null 2>&1
        apt-get autoremove -y >/dev/null 2>&1
        dpkg -l |grep ^rc|awk '{print $2}' |xargs dpkg -P >/dev/null 2>&1
}

install_aria2()
    {
        if [ -d "/tmp/VPS" ]; then
        echo "VPS.tar.gz已下载"
else
        get_VPS_file
        fi
        aria2_time=$(wget -qO- --no-check-certificate https://api.github.com/repos/P3TERX/Aria2-Pro-Core/releases/latest | grep 'tag_name' |  cut -d\" -f4 | sed s/release-//g | sed s/v//g)
        aria2_ver=$(echo $aria2_time | cut -d  '_' -f1)
        echo [$LOGTIME] 正在安装Aria2 v${aria2_ver}...
        apt-get update >/dev/null 2>&1
        apt-get install jq -y >/dev/null 2>&1
        wget --no-check-certificate -qO- "https://github.com/P3TERX/Aria2-Pro-Core/releases/download/${aria2_time}/aria2-${aria2_ver}-static-linux-${aria2_bit}.tar.gz" -O '/usr/local/sh/aria2.tar.gz'
        mkdir /tmp/aria2/
        tar -zxvf  /usr/local/sh/aria2.tar.gz -C /tmp/aria2/ >/dev/null 2>&1
        mv /tmp/aria2/aria2c /usr/local/bin/aria2c
        chmod +x /usr/local/bin/aria2c
        rm /usr/local/sh/aria2.tar.gz
        rm -r /tmp/aria2
        mv /tmp/VPS/VPS/AK/etc/systemd/system/aria2.service /etc/systemd/system/aria2.service
        chmod +x /etc/systemd/system/aria2.service
        mv /tmp/VPS/VPS/AK/root/.aria2c /root/.aria2c
        systemctl enable aria2
        systemctl start aria2
        del_VPS_file
}

install_xray()
    {
        if [ -d "/tmp/VPS" ]; then
        echo "VPS.tar.gz已下载"
else
        get_VPS_file
        fi
#安装Xray
        xray_ver=$(wget -qO- --no-check-certificate https://github.com/XTLS/Xray-core/tags | grep 'class=\"Link--primary Link\"' | awk '{print $8}' | cut -d v -f2 | cut -d \< -f0 | head -n 1)
        echo [$LOGTIME] 正在安装Xray v${xray_ver}...
        apt-get update >/dev/null 2>&1
        apt-get install unzip curl -y >/dev/null 2>&1
        wget --no-check-certificate -qO- "https://github.com/XTLS/Xray-core/releases/download/v${xray_ver}/xray-linux-${xray_bit}.zip" -O '/usr/local/sh/xray.zip'
        mkdir -p /tmp/xray/
        unzip /usr/local/sh/xray.zip -d /tmp/xray/ >/dev/null 2>&1
        mv /tmp/xray/xray /usr/local/bin/xray
        wget --no-check-certificate -qO- "https://github.com/Loyalsoldier/v2ray-rules-dat/releases/latest/download/geoip.dat" -O '/usr/local/bin/geoip.dat'
        wget --no-check-certificate -qO- "https://github.com/Loyalsoldier/v2ray-rules-dat/releases/latest/download/geosite.dat" -O '/usr/local/bin/geosite.dat'
        chmod 755 /usr/local/bin/xray
        rm /usr/local/sh/xray.zip
        rm -r /tmp/xray
        mv /tmp/VPS/VPS/AK/etc/systemd/system/xray.service /etc/systemd/system/xray.service
        chmod +x /etc/systemd/system/xray.service
        mkdir -p /usr/local/etc/xray
        mv /tmp/VPS/VPS/AK/usr/local/etc/xray/config.json /usr/local/etc/xray/config.json
        systemctl enable xray
        systemctl start xray    
#开启BBR
        echo "net.core.default_qdisc=fq" >> /etc/sysctl.conf
        echo "net.ipv4.tcp_congestion_control=bbr" >> /etc/sysctl.conf
        sysctl -p
#安装ACME
        mv /tmp/VPS/VPS/AK/root/.acme.sh /root/.acme.sh
        chmod  -R +x /root/.acme.sh
#安装NGINX
        mv /tmp/VPS/VPS/AK/usr/local/nginx /usr/local/nginx
        chmod -R 755 /usr/local/nginx/sbin/nginx
        chmod -R +x /usr/local/nginx/modules
        mv /tmp/VPS/VPS/AK/var/www /var/www
        mv /tmp/VPS/VPS/AK/etc/systemd/system/nginx.service /etc/systemd/system/nginx.service
        chmod +x /etc/systemd/system/nginx.service
        mv /tmp/VPS/VPS/AK/usr/lib/i386-linux-gnu/libprofiler.so.0.5.1 /usr/lib/i386-linux-gnu/libprofiler.so.0.5.1
        chmod +x /usr/lib/i386-linux-gnu/libprofiler.so.0.5.1
        ln -s /usr/lib/i386-linux-gnu/libprofiler.so.0.5.1 /usr/lib/i386-linux-gnu/libprofiler.so.0
        rm /usr/lib/i386-linux-gnu/libcrypt.so.1
        rm /usr/lib/i386-linux-gnu/libcrypt-2.28.so
        mv /tmp/VPS/VPS/AK/usr/lib/i386-linux-gnu/libcrypt-2.28.so /usr/lib/i386-linux-gnu/libcrypt-2.28.so
        chmod +x /usr/lib/i386-linux-gnu/libcrypt-2.28.so
        ln -s /usr/lib/i386-linux-gnu/libcrypt-2.28.so /usr/lib/i386-linux-gnu/libcrypt.so.1
        systemctl enable nginx
        systemctl start nginx
        del_VPS_file
}

install_alist()
    {
        if [ -d "/tmp/VPS" ]; then
        echo "VPS.tar.gz已下载"
else
        get_VPS_file
        fi
        alist_ver=$(wget -qO- --no-check-certificate https://api.github.com/repos/alist-org/alist/releases/latest | grep 'tag_name' | cut -d\" -f4| sed s/v//g)
        echo [$LOGTIME] 正在安装Alist v${alist_ver}...
        wget --no-check-certificate -qO- "https://github.com/alist-org/alist/releases/download/v${alist_ver}/alist-linux-${alist_bit}.tar.gz" -O '/usr/local/sh/alist.tar.gz'
        mkdir -p /tmp/alist/
        mv /tmp/VPS/VPS/AK/etc/systemd/system/alist.service /etc/systemd/system/alist.service
        mv /tmp/VPS/VPS/AK/usr/local/etc/alist /usr/local/etc/alist
        chmod +x /etc/systemd/system/alist.service
        tar -zxvf  /usr/local/sh/alist.tar.gz -C /tmp/alist/ >/dev/null 2>&1
        mv /tmp/alist/alist /usr/local/bin/alist
        chmod -R 755 /usr/local/bin/alist
        rm /usr/local/sh/alist.tar.gz
        rm -r /tmp/alist
        systemctl enable alist
        systemctl start alist
        del_VPS_file
}

install_status()
    {
        if [ -d "/tmp/VPS" ]; then
        echo "VPS.tar.gz已下载"
else
        get_VPS_file
        fi
        status_ver=$(wget -qO- --no-check-certificate https://api.github.com/repos/cokemine/ServerStatus-goclient/releases/latest | grep 'tag_name' |  cut -d\" -f4 | sed s/release-//g | sed s/v//g)
        echo [$LOGTIME] 正在安装ServerStatus v${status_ver}...
        apt-get update >/dev/null 2>&1
        apt install vnstat -y >/dev/null 2>&1
        wget --no-check-certificate -qO- "https://github.com/cokemine/ServerStatus-goclient/releases/download/v${status_ver}/status-client_linux_${status_bit}.tar.gz" -O '/usr/local/sh/status.tar.gz' 
        mkdir -p /tmp/status/
        tar -xzvf /usr/local/sh/status.tar.gz -C /tmp/status/ >/dev/null 2>&1
        touch /usr/local/bin/status_ver
        echo ${status_ver} > /usr/local/bin/status_ver
        mv /tmp/status/status-client /usr/local/bin/status-client        
        chmod 755 /usr/local/bin/status-client
        rm /usr/local/sh/status.tar.gz
        rm -r /tmp/status/
        mv /tmp/VPS/VPS/AK/etc/systemd/system/status.service /etc/systemd/system/status.service
        chmod +x /etc/systemd/system/getip.service
        systemctl enable getip
        systemctl start getip
        chmod +x /etc/systemd/system/status.service
        systemctl enable status
        systemctl start status
        mv /tmp/VPS/VPS/AK/etc/systemd/system/getip.service /etc/systemd/system/getip.service
        del_VPS_file
}

install_all()
    {
        install_aria2
        install_alist
        install_xray
        install_status
        if [ -d "/tmp/VPS" ]; then
        echo "VPS.tar.gz已下载"
else
        get_VPS_file
        fi
        rm -r /usr/local/sh/
        mv /tmp/VPS/VPS/AK/usr/local/sh /usr/local/
        chmod +x /usr/local/sh/dog.sh
        chmod +x /usr/local/sh/Install.sh
        chmod +x /usr/local/sh/log.sh
        del_VPS_file
}
      
remove_aria2()
    {
         echo [$LOGTIME] 正在卸载Aria2...
         apt-get --purge remove jq -y >/dev/null 2>&1
         systemctl stop aria2
         systemctl disable aria2
         rm /etc/systemd/system/aria2.service
         rm /usr/local/bin/aria2c
         rm -r /root/.aria2c
}

remove_alist()
    {
         echo [$LOGTIME] 正在卸载Alist...
         rm /usr/local/bin/alist 
         rm /etc/systemd/system/alist.service
         rm -r /usr/local/etc/alist
}

remove_xray()
    {
         echo [$LOGTIME] 正在卸载Xray...
         apt-get --purge remove unzip curl -y
         systemctl stop xray
         rm /usr/local/bin/xray
         rm /usr/local/bin/geosite.dat
         rm /usr/local/bin/geoip.dat
         rm -r /usr/local/etc/xray
         systemctl disable xray
         rm /etc/systemd/system/xray.service 
         systemctl stop nginx
         rm -r /usr/local/nginx/sbin/nginx
         rm -r /var/www
         rm /usr/lib/i386-linux-gnu/libprofiler.so.0.5.1
         rm /usr/lib/i386-linux-gnu/libprofiler.so.0
         systemctl disable nginx
         rm /etc/systemd/system/nginx.service 
         rm -r /root/.acme.sh
}

remove_status()
    {
         echo [$LOGTIME] 正在卸载ServerStatus...
         apt-get --purge remove vnstat -y
         rm /usr/local/bin/status-client
         rm /usr/local/bin/status_ver
         systemctl disable status
         rm /etc/systemd/system/status.service
         systemctl disable getip
         rm /etc/systemd/system/getip.service
} 

remove_all()
    {
         remove_aria2
         remove_alist
         remove_xray
         remove_status
} 
       
update_aria2()
    {
        aria2_time=$(wget -qO- --no-check-certificate https://api.github.com/repos/P3TERX/Aria2-Pro-Core/releases/latest | grep 'tag_name' |  cut -d\" -f4 | sed s/release-//g | sed s/v//g)
        aria2_ver=$(echo $aria2_time | cut -d  '_' -f1)
        l_aria2_ver=$(/usr/local/bin/aria2c -v | head -n 1 | cut -d " " -f3 )
        if [ -n "$aria2_ver" ] && [ "$aria2_ver" != "$l_aria2_ver" ]; then
        echo [$LOGTIME] 发现Aria2新版本 ${aria2_ver}
         systemctl stop aria2
        wget --no-check-certificate -qO- "https://github.com/P3TERX/Aria2-Pro-Core/releases/download/${aria2_time}/aria2-${aria2_ver}-static-linux-${aria2_bit}.tar.gz" -O '/usr/local/sh/aria2.tar.gz'
        mkdir /tmp/aria2/
        tar -zxvf  /usr/local/sh/aria2.tar.gz -C /tmp/aria2/ >/dev/null 2>&1
        mv /tmp/aria2/aria2c /usr/local/bin/aria2c
        chmod +x /usr/local/bin/aria2c
        rm /usr/local/sh/aria2.tar.gz
        rm -r /tmp/aria2

sleep 1
         systemctl start aria2
else
        echo [$LOGTIME] 未发现Aria2更新...
fi
}

update_alist()
    {
        alist_ver=$(wget -qO- --no-check-certificate https://api.github.com/repos/alist-org/alist/releases/latest | grep 'tag_name' | cut -d\" -f4| sed s/v//g)
        l_alist_ver=$(/usr/local/bin/alist version | grep Version | head -n 2 | tail -n 1 | cut -d " " -f2 | sed s/v//g)
        if [ -n "$alist_ver" ] && [ "$alist_ver" != "$l_alist_ver" ]; then
        echo [$LOGTIME] 发现Alist新版本 ${alist_ver}
        wget --no-check-certificate -qO- "https://github.com/alist-org/alist/releases/download/v${alist_ver}/alist-linux-${alist_bit}.tar.gz" -O '/usr/local/sh/alist.tar.gz'
        mkdir -p /tmp/alist/
        tar -zxvf  /usr/local/sh/alist.tar.gz -C /tmp/alist/ >/dev/null 2>&1
        systemctl stop alist
        mv /tmp/alist/alist /usr/local/bin/alist
        chmod -R 755 /usr/local/bin/alist
        systemctl start alist
        rm -r /tmp/alist
        rm /usr/local/sh/alist.tar.gz
else
        echo [$LOGTIME] 未发现Alist更新...
fi
}

update_xray()
    {
        xray_ver=$(wget -qO- --no-check-certificate https://github.com/XTLS/Xray-core/tags | grep 'class=\"Link--primary Link\"' | awk '{print $8}' | cut -d v -f2 | cut -d \< -f0 | head -n 1)
        wget --no-check-certificate -qO- "https://github.com/Loyalsoldier/v2ray-rules-dat/releases/latest/download/geoip.dat" -O '/usr/local/bin/geoip.dat'
        wget --no-check-certificate -qO- "https://github.com/Loyalsoldier/v2ray-rules-dat/releases/latest/download/geosite.dat" -O '/usr/local/bin/geosite.dat'
        l_xray_ver=$(/usr/local/bin/xray -version | head -n 1 | cut -d " " -f2 | sed s/v//g)
        if [ -n "$xray_ver" ] && [ "$xray_ver" != "$l_xray_ver" ]; then
        echo [$LOGTIME] 发现Xray新版本 ${xray_ver}
         systemctl stop xray
         wget --no-check-certificate -qO- "https://github.com/XTLS/Xray-core/releases/download/v${xray_ver}/xray-linux-${xray_bit}.zip" -O '/usr/local/sh/xray.zip'
        mkdir -p /tmp/xray/
        unzip /usr/local/sh/xray.zip -d /tmp/xray/ >/dev/null 2>&1
        mv /tmp/xray/xray /usr/local/bin/xray
        chmod 755 /usr/local/bin/xray
        rm /usr/local/sh/xray.zip
        rm -r /tmp/xray
sleep 1
         systemctl start xray
else
        echo [$LOGTIME] 未发现Xray更新...
fi
}

update_status()
    {
        status_ver=$(wget -qO- --no-check-certificate https://api.github.com/repos/cokemine/ServerStatus-goclient/releases/latest | grep 'tag_name' |  cut -d\" -f4 | sed s/release-//g | sed s/v//g)
        l_status_ver=$(cat /usr/local/bin/status_ver)        
        if [ -n "$l_status_ver" ] && [ "$status_ver" != "$l_status_ver" ]; then 
        echo [$LOGTIME] 发现ServerStatus新版本 ${status_ver}
        systemctl start status
        echo [$LOGTIME] 正在安装ServerStatus v${status_ver}...
        wget --no-check-certificate -qO- "https://github.com/cokemine/ServerStatus-goclient/releases/download/v${status_ver}/status-client_linux_${status_bit}.tar.gz" -O '/usr/local/sh/status.tar.gz'
        mkdir -p /tmp/status/
        tar -xzvf /usr/local/sh/status.tar.gz -C /tmp/status/ >/dev/null 2>&1
        echo ${status_ver} > /usr/local/bin/status_ver
        mv /tmp/status/status-client /usr/local/bin/status-client        
        chmod 755 /usr/local/bin/status-client
        rm /usr/local/sh/status.tar.gz
        rm -r /tmp/status/ 

sleep 1
         systemctl stop status
else
        echo [$LOGTIME] 未发现ServerStatus更新...
fi
}

update_all()
    {
        update_aria2
        update_xray
        update_status
        update_alist
        apt-get update -y && apt-get upgrade -y 
        apt-get autoclean -y
        apt-get clean -y
        apt-get autoremove -y
        dpkg -l |grep ^rc|awk '{print $2}' |xargs dpkg -P
}

if [ $# -ge 1 ];
then
while [ $# -ge 1 ]; do
    case $1 in
        0|install_all) 
            install_all
            if [ $# -gt 0 ]; then
            shift
            fi
            ;;
        1|install_aria2) 
            install_aria2
            if [ $# -gt 0 ]; then
            shift
            fi
            ;;
        2|install_alist) 
            install_alist
            if [ $# -gt 0 ]; then
            shift
            fi
            ;;
        3|install_xray) 
            install_xray
            if [ $# -gt 0 ]; then
            shift
            fi
            ;;
        4|install_status) 
            install_status
            if [ $# -gt 0 ]; then
            shift
            fi
            ;;
        5|remove_all) 
            remove_all
            if [ $# -gt 0 ]; then
            shift
            fi
            ;;
        6|remove_aria2) 
            remove_aria2
            if [ $# -gt 0 ]; then
            shift
            fi
            ;;
        7|remove_alist) 
            remove_alist
            if [ $# -gt 0 ]; then
            shift
            fi
            ;;
        8|remove_xray) 
            remove_xray
            if [ $# -gt 0 ]; then
            shift
            fi
            ;;
        9|remove_status) 
            remove_status
            if [ $# -gt 0 ]; then
            shift
            fi
            ;;
        10|update_all) 
            update_all
            if [ $# -gt 0 ]; then
            shift
            fi
            ;;
        11|update_aria2) 
            update_aria2
            if [ $# -gt 0 ]; then
            shift
            fi
            ;;
        12|update_xray) 
            update_xray
            if [ $# -gt 0 ]; then
            shift
            fi
            ;;
        13|update_status) 
            update_status
            if [ $# -gt 0 ]; then
            shift
            fi
            ;;
        14|update_alist) 
            update_alist
            if [ $# -gt 0 ]; then
            shift
            fi
            ;;
        *)
            break;
            ;;                    
    esac
done
else
echo && echo " 
————————————————————————
0 全部安装
1 安装 Aria2
2 安装 Alist
3 安装 Xray
4 安装 ServerStatus
————————————————————————
5 全部卸载
6 卸载 Aria2
7 卸载 Alist
8 卸载 Xray
9 卸载 ServerStatus
————————————————————————
10 全部更新
11 更新 Aria2
12 更新 Xray
13 更新 ServerStatus
14 更新 Alist
————————————————————————" && echo
read -p "请输入数字 [0-14]:" num     
    case $num in
        0|install_all) 
            install_all
            if [ $# -gt 0 ]; then
            shift
            fi
            ;;
        1|install_aria2) 
            install_aria2
            if [ $# -gt 0 ]; then
            shift
            fi
            ;;
        2|install_alist) 
            install_alist
            if [ $# -gt 0 ]; then
            shift
            fi
            ;;
        3|install_xray) 
            install_xray
            if [ $# -gt 0 ]; then
            shift
            fi
            ;;
        4|install_status) 
            install_status
            if [ $# -gt 0 ]; then
            shift
            fi
            ;;
        5|remove_all) 
            remove_all
            if [ $# -gt 0 ]; then
            shift
            fi
            ;;
        6|remove_aria2) 
            remove_aria2
            if [ $# -gt 0 ]; then
            shift
            fi
            ;;
        7|remove_alist) 
            remove_alist
            if [ $# -gt 0 ]; then
            shift
            fi
            ;;
        8|remove_xray) 
            remove_xray
            if [ $# -gt 0 ]; then
            shift
            fi
            ;;
        9|remove_status) 
            remove_status
            if [ $# -gt 0 ]; then
            shift
            fi
            ;;
        10|update_all) 
            update_all
            if [ $# -gt 0 ]; then
            shift
            fi
            ;;
        11|update_aria2) 
            update_aria2
            if [ $# -gt 0 ]; then
            shift
            fi
            ;;
        12|update_xray) 
            update_xray
            if [ $# -gt 0 ]; then
            shift
            fi
            ;;
        13|update_status) 
            update_status
            if [ $# -gt 0 ]; then
            shift
            fi
            ;;
        14|update_alist) 
            update_alist
            if [ $# -gt 0 ]; then
            shift
            fi
            ;;
        *)
            break;
            ;;                    
    esac
fi