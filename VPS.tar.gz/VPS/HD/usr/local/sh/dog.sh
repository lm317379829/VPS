#!/bin/sh
. /etc/profile
LOGTIME=$(date "+%Y-%m-%d %H:%M:%S")

check_status()
    { 
           ip_old=$(ps -ef|grep /usr/local/bin/status-client|grep -v grep)
           ip_old=${ip_old#*041390@}
           ip_old=${ip_old%%:*}
           ip_new=$(ping -c 1 www.lmhome.tk | grep PING | awk '{print $3}' | sed s/\(//g | sed s/\)//g)
           echo  -n ip=$ip_new > /tmp/ip.env
           if [ "$ip_old" != "$ip_new" ]; then
            systemctl restart status
           fi
}

check()
    {
        check_status
}

getip()
    {
        echo -n ip=$(ping -c 1 www.lmhome.tk | grep PING | awk '{print $3}' | sed s/\(//g | sed s/\)//g) > /tmp/ip.env
}

INPUT=$1
if [ -z "$1" ]
then    
check
else     
case "$INPUT" in
check_status) check_status;;
getip) getip;;
esac
fi