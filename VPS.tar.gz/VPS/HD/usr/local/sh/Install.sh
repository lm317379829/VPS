#!/bin/sh
. /etc/profile
LOGTIME=$(date "+%Y-%m-%d %H:%M:%S")

wget_ver=$(wget -V | grep 'built on linux-gnu')
if [ ! -n "$wget_ver" ]; then
apt-get update >/dev/null 2>&1
apt-get install wget -y >/dev/null 2>&1
fi

aria2_bit=i386
xray_bit=32
rclone_bit=386
status_bit=386
alistp_bit=386

get_VPS_file()
    {
        wget --no-check-certificate -qO- "https://raw.githubusercontent.com/lm317379829/VPS/main/VPS.tar.gz"  -O '/usr/local/sh/VPS.tar.gz'
        mkdir -p /tmp/VPS/
        tar -xzvf /usr/local/sh/VPS.tar.gz -C /tmp/VPS/ >/dev/null 2>&1
}

del_VPS_file()
    {
        rm /usr/local/sh/VPS.tar.gz
        rm -r /tmp/VPS/
        apt-get autoclean -y
        apt-get clean -y
        apt-get autoremove -y
        dpkg -l |grep ^rc|awk '{print $2}' |xargs dpkg -P
}

install_aria2()
    {
        if [ -d "/tmp/VPS" ]; then
        echo "VPS.tar.gz已下载"
else
        get_VPS_file
        fi
        aria2_time=$(wget -qO- --no-check-certificate https://api.github.com/repos/P3TERX/Aria2-Pro-Core/releases/latest | grep 'tag_name' |  cut -d\" -f4 | sed s/release-//g | sed s/v//g)
        aria2_ver=$(echo $aria2_time | cut -d  '_' -f1)
        echo [$LOGTIME] 正在安装Aria2 v${aria2_ver}...
        apt-get update >/dev/null 2>&1
        apt-get install jq -y >/dev/null 2>&1
        wget --no-check-certificate -qO- "https://github.com/P3TERX/Aria2-Pro-Core/releases/download/${aria2_time}/aria2-${aria2_ver}-static-linux-${aria2_bit}.tar.gz" -O '/usr/local/sh/aria2.tar.gz'
        mkdir /tmp/aria2/
        tar -zxvf  /usr/local/sh/aria2.tar.gz -C /tmp/aria2/ >/dev/null 2>&1
        mv /tmp/aria2/aria2c /usr/local/bin/aria2c
        chmod +x /usr/local/bin/aria2c
        rm /usr/local/sh/aria2.tar.gz
        rm -r /tmp/aria2
        mv /tmp/VPS/VPS/HD/etc/systemd/system/aria2.service /etc/systemd/system/aria2.service
        chmod +x /etc/systemd/system/aria2.service
        mv /tmp/VPS/VPS/HD/root/.aria2c /root/.aria2c
        systemctl enable aria2
        systemctl start aria2
        del_VPS_file
}

install_xray()
    {
        if [ -d "/tmp/VPS" ]; then
        echo "VPS.tar.gz已下载"
else
        get_VPS_file
        fi
#安装Xray
        xray_ver=$(wget -qO- --no-check-certificate https://github.com/XTLS/Xray-core/releases/latest | grep '<title>Release' | awk '{print $3}' | sed s/v//g)
        echo [$LOGTIME] 正在安装Xray v${xray_ver}...
        apt-get update >/dev/null 2>&1
        apt-get install unzip curl -y >/dev/null 2>&1
        wget --no-check-certificate -qO- "https://github.com/XTLS/Xray-core/releases/download/v${xray_ver}/xray-linux-${xray_bit}.zip" -O '/usr/local/sh/xray.zip'
        mkdir -p /tmp/xray/
        unzip /usr/local/sh/xray.zip -d /tmp/xray/ >/dev/null 2>&1
        mv /tmp/xray/xray /usr/local/bin/xray
        wget --no-check-certificate -qO- "https://github.com/Loyalsoldier/v2ray-rules-dat/releases/latest/download/geoip.dat" -O '/usr/local/bin/geoip.dat'
        wget --no-check-certificate -qO- "https://github.com/Loyalsoldier/v2ray-rules-dat/releases/latest/download/geosite.dat" -O '/usr/local/bin/geosite.dat'
        chmod 755 /usr/local/bin/xray
        rm /usr/local/sh/xray.zip
        rm -r /tmp/xray
        mv /tmp/VPS/VPS/HD/etc/systemd/system/xray.service /etc/systemd/system/xray.service
        chmod +x /etc/systemd/system/xray.service
        mv /tmp/VPS/VPS/HD/usr/local/etc/xray/config.json /usr/local/etc/xray/config.json
        systemctl enable xray
        systemctl start xray    
#开启BBR
        echo "net.core.default_qdisc=fq" >> /etc/sysctl.conf
        echo "net.ipv4.tcp_congestion_control=bbr" >> /etc/sysctl.conf
        sysctl -p
#安装ACME
        mv /tmp/VPS/VPS/HD/root/.acme.sh /root/.acme.sh
        chmod  -R +x /root/.acme.sh
#安装NGINX
        mv /tmp/VPS/VPS/HD/usr/local/nginx /usr/local/nginx
        chmod -R 755 /usr/local/nginx/sbin/nginx
        chmod -R +x /usr/local/nginx/modules
        mv /tmp/VPS/VPS/HD/var/www /var/www
        mv /tmp/VPS/VPS/HD/etc/systemd/system/nginx.service /etc/systemd/system/nginx.service
        chmod +x /etc/systemd/system/nginx.service
        mv /tmp/VPS/VPS/HD/usr/lib/i386-linux-gnu/libprofiler.so.0.5.1 /usr/lib/i386-linux-gnu/libprofiler.so.0.5.1
        chmod +x /usr/lib/i386-linux-gnu/libprofiler.so.0.5.1
        ln -s /usr/lib/i386-linux-gnu/libprofiler.so.0.5.1 /usr/lib/i386-linux-gnu/libprofiler.so.0
        rm /usr/lib/i386-linux-gnu/libcrypt.so.1
        rm /usr/lib/i386-linux-gnu/libcrypt-2.28.so
        mv /tmp/VPS/VPS/HD/usr/lib/i386-linux-gnu/libcrypt-2.28.so /usr/lib/i386-linux-gnu/libcrypt-2.28.so
        chmod +x /usr/lib/i386-linux-gnu/libcrypt-2.28.so
        ln -s /usr/lib/i386-linux-gnu/libcrypt-2.28.so /usr/lib/i386-linux-gnu/libcrypt.so.1
        systemctl enable nginx
        systemctl start nginx
        del_VPS_file
}

install_rclone()
    {
        if [ -d "/tmp/VPS" ]; then
        echo "VPS.tar.gz已下载"
else
        get_VPS_file
        fi
        rclone_ver=$(wget -qO- --no-check-certificate https://api.github.com/repos/rclone/rclone/releases/latest | grep 'tag_name' | cut -d\" -f4| sed s/v//g)
        echo [$LOGTIME] 正在安装Rclone v${rclone_ver}...
        apt-get update >/dev/null 2>&1
        apt-get install unzip curl -y >/dev/null 2>&1
        wget --no-check-certificate -qO- "https://github.com/rclone/rclone/releases/download/v${rclone_ver}/rclone-v${rclone_ver}-linux-${rclone_bit}.zip" -O '/usr/local/sh/rclone.zip'
        mkdir -p /tmp/rclone/
        unzip /usr/local/sh/rclone.zip -d /tmp/rclone/ >/dev/null 2>&1
        mv /tmp/rclone/rclone-v${rclone_ver}-linux-${rclone_bit}/rclone /usr/local/bin/
        chmod -R 755 /usr/local/bin/rclone
        rm /usr/local/sh/rclone.zip
        rm -r /tmp/rclone
        mv /tmp/VPS/VPS/HD/root/.config /root/.config
        del_VPS_file
}

install_status()
    {
        if [ -d "/tmp/VPS" ]; then
        echo "VPS.tar.gz已下载"
else
        get_VPS_file
        fi
        status_ver=$(wget -qO- --no-check-certificate https://api.github.com/repos/cokemine/ServerStatus-goclient/releases/latest | grep 'tag_name' |  cut -d\" -f4 | sed s/release-//g | sed s/v//g)
        echo [$LOGTIME] 正在安装ServerStatus v${status_ver}...
        apt-get update >/dev/null 2>&1
        apt install vnstat -y >/dev/null 2>&1
        wget --no-check-certificate -qO- "https://github.com/cokemine/ServerStatus-goclient/releases/download/v${status_ver}/status-client_linux_${status_bit}.tar.gz" -O '/usr/local/sh/status.tar.gz' 
        mkdir -p /tmp/status/
        tar -xzvf /usr/local/sh/status.tar.gz -C /tmp/status/ >/dev/null 2>&1
        touch /usr/local/bin/status_ver
        echo ${status_ver} > /usr/local/bin/status_ver
        mv /tmp/status/status-client /usr/local/bin/status-client        
        chmod 755 /usr/local/bin/status-client
        rm /usr/local/sh/status.tar.gz
        rm -r /tmp/status/
        mv /tmp/VPS/VPS/HD/etc/systemd/system/status.service /etc/systemd/system/status.service
        chmod +x /etc/systemd/system/status.service
        systemctl enable status
        systemctl start status
        del_VPS_file
}

install_alistp()
    {
        if [ -d "/tmp/VPS" ]; then
        echo "VPS.tar.gz已下载"
else
        get_VPS_file
        fi
        alistp_ver=$(wget -qO- --no-check-certificate https://api.github.com/repos/alist-org/alist-proxy/releases/latest | grep 'tag_name' |  cut -d\" -f4 | sed s/release-//g | sed s/v//g)
        echo [$LOGTIME] 正在安装Alist-Proxy v${alistp_ver}...
        wget --no-check-certificate -qO- "https://github.com/alist-org/alist-proxy/releases/download/v${alistp_ver}/alist-proxy_${alistp_ver}_linux_${alistp_bit}.tar.gz" -O '/usr/local/sh/alistp.tar.gz' 
        mkdir -p /tmp/alistp/
        tar -xzvf /usr/local/sh/alistp.tar.gz -C /tmp/alistp/ >/dev/null 2>&1
        touch /usr/local/bin/alistp_ver
        echo ${alistp_ver} > /usr/local/bin/alistp_ver
        mv /tmp/alistp/alist-proxy /usr/local/bin/alist-proxy        
        chmod 755 /usr/local/bin/alist-proxy
        rm /usr/local/sh/alistp.tar.gz
        rm -r /tmp/alistp/
        mv /tmp/VPS/VPS/HD/etc/systemd/system/alistp.service /etc/systemd/system/alistp.service
        chmod +x /etc/systemd/system/alistp.service
        systemctl enable alistp
        systemctl start alistp
        del_VPS_file
}

install_all()
    {
        install_aria2
        install_rclone
        install_xray
        install_status
        install_alistp 
        if [ -d "/tmp/VPS" ]; then
        echo "VPS.tar.gz已下载"
else
        get_VPS_file
        fi
        mv /tmp/VPS/VPS/HD/usr/local/sh/ /usr/local/sh/
        chmod +x /usr/local/sh/dog.sh
        chmod +x /usr/local/sh/Install.sh
        chmod +x /usr/local/sh/log.sh
        del_VPS_file
}

remove_alistp()
    {
         echo [$LOGTIME] 正在卸载Alist-Proxy...
         systemctl stop alistp
         systemctl disable alistp
         rm /etc/systemd/system/alistp.service
         rm /usr/local/bin/alistp_ver
         rm /usr/local/bin/alist-proxy
}
      
remove_aria2()
    {
         echo [$LOGTIME] 正在卸载Aria2...
         apt-get --purge remove jq -y >/dev/null 2>&1
         systemctl stop aria2
         systemctl disable aria2
         rm /etc/systemd/system/aria2.service
         rm /usr/local/bin/aria2c
         rm -r /root/.aria2c
}

remove_rclone()
    {
         echo [$LOGTIME] 正在卸载Rclone...
         rm -r /usr/local/bin/rclone 
         rm -r /root/.config
}

remove_xray()
    {
         echo [$LOGTIME] 正在卸载Xray...
         apt-get --purge remove unzip curl -y
         systemctl stop xray
         rm /usr/local/bin/xray
         rm /usr/local/bin/geosite.dat
         rm /usr/local/bin/geoip.dat
         rm -r /usr/local/etc/xray
         systemctl disable xray
         rm /etc/systemd/system/xray.service 
         systemctl stop nginx
         rm -r /usr/local/nginx/sbin/nginx
         rm -r /var/www
         rm /usr/lib/i386-linux-gnu/libprofiler.so.0.5.1
         rm /usr/lib/i386-linux-gnu/libprofiler.so.0
         systemctl disable nginx
         rm /etc/systemd/system/nginx.service 
         rm -r /root/.acme.sh
}

remove_status()
    {
         echo [$LOGTIME] 正在卸载ServerStatus...
         apt-get --purge remove vnstat -y
         rm /usr/local/bin/status-client
         rm /usr/local/bin/status_ver
} 

remove_all()
    {
         remove_aria2
         remove_rclone
         remove_xray
         remove_status
         remove_alistp
} 
       
update_alistp()
    {
        alistp_ver=$(wget -qO- --no-check-certificate https://api.github.com/repos/alist-org/alist-proxy/releases/latest | grep 'tag_name' |  cut -d\" -f4 | sed s/release-//g | sed s/v//g)
        l_alistp_ver=$(cat /usr/local/bin/alistp_ver)
        if [ -n "$alistp_ver" ] && [ "$alistp_ver" != "$l_alistp_ver" ]; then
        echo [$LOGTIME] 发现Alist-Proxy新版本 ${alistp_ver}
         systemctl stop alistp
        wget --no-check-certificate -qO- "https://github.com/alist-org/alist-proxy/releases/download/v${alistp_ver}/alist-proxy_${alistp_ver}_linux_${alistp_bit}.tar.gz" -O '/usr/local/sh/alistp.tar.gz' 
        mkdir -p /tmp/alistp/
        tar -xzvf /usr/local/sh/alistp.tar.gz -C /tmp/alistp/ >/dev/null 2>&1
        touch /usr/local/bin/alistp_ver
        echo ${alistp_ver} > /usr/local/bin/alistp_ver
        mv /tmp/alistp/alist-proxy /usr/local/bin/alist-proxy        
        chmod 755 /usr/local/bin/alist-proxy
        rm /usr/local/sh/alistp.tar.gz
        rm -r /tmp/alistp/
sleep 1
         systemctl start alistp
else
        echo [$LOGTIME] 未发现Alist-Proxy更新...
fi
}

update_aria2()
    {
        aria2_time=$(wget -qO- --no-check-certificate https://api.github.com/repos/P3TERX/Aria2-Pro-Core/releases/latest | grep 'tag_name' |  cut -d\" -f4 | sed s/release-//g | sed s/v//g)
        aria2_ver=$(echo $aria2_time | cut -d  '_' -f1)
        l_aria2_ver=$(/usr/local/bin/aria2c -v | head -n 1 | cut -d " " -f3 )
        if [ -n "$aria2_ver" ] && [ "$aria2_ver" != "$l_aria2_ver" ]; then
        echo [$LOGTIME] 发现Aria2新版本 ${aria2_ver}
         systemctl stop aria2
        wget --no-check-certificate -qO- "https://github.com/P3TERX/Aria2-Pro-Core/releases/download/${aria2_time}/aria2-${aria2_ver}-static-linux-${aria2_bit}.tar.gz" -O '/usr/local/sh/aria2.tar.gz'
        mkdir /tmp/aria2/
        tar -zxvf  /usr/local/sh/aria2.tar.gz -C /tmp/aria2/ >/dev/null 2>&1
        mv /tmp/aria2/aria2c /usr/local/bin/aria2c
        chmod +x /usr/local/bin/aria2c
        rm /usr/local/sh/aria2.tar.gz
        rm -r /tmp/aria2

sleep 1
         systemctl start aria2
else
        echo [$LOGTIME] 未发现Aria2更新...
fi
}

update_rclone()
    {
        rclone_ver=$(wget -qO- --no-check-certificate https://api.github.com/repos/rclone/rclone/releases/latest | grep 'tag_name' | cut -d\" -f4| sed s/v//g)
        l_rclone_ver=$(/usr/local/bin/rclone version | head -n 1 | cut -d " " -f2 | sed s/v//g)
        if [ -n "$rclone_ver" ] && [ "$rclone_ver" != "$l_rclone_ver" ]; then
        echo [$LOGTIME] 发现Rclone新版本 ${rclone_ver}
        install_rclone
else
        echo [$LOGTIME] 未发现Rclone更新...
fi
}

update_xray()
    {
        xray_ver=$(wget -qO- --no-check-certificate https://github.com/XTLS/Xray-core/releases/latest | grep '<title>Release' | awk '{print $3}' | sed s/v//g)
        wget --no-check-certificate -qO- "https://github.com/Loyalsoldier/v2ray-rules-dat/releases/latest/download/geoip.dat" -O '/usr/local/bin/geoip.dat'
        wget --no-check-certificate -qO- "https://github.com/Loyalsoldier/v2ray-rules-dat/releases/latest/download/geosite.dat" -O '/usr/local/bin/geosite.dat'
        l_xray_ver=$(/usr/local/bin/xray -version | head -n 1 | cut -d " " -f2 | sed s/v//g)
        if [ -n "$xray_ver" ] && [ "$xray_ver" != "$l_xray_ver" ]; then
        echo [$LOGTIME] 发现Xray新版本 ${xray_ver}
         systemctl stop xray
         wget --no-check-certificate -qO- "https://github.com/XTLS/Xray-core/releases/download/v${xray_ver}/xray-linux-${xray_bit}.zip" -O '/usr/local/sh/xray.zip'
        mkdir -p /tmp/xray/
        unzip /usr/local/sh/xray.zip -d /tmp/xray/ >/dev/null 2>&1
        mv /tmp/xray/xray /usr/local/bin/xray
        chmod 755 /usr/local/bin/xray
        rm /usr/local/sh/xray.zip
        rm -r /tmp/xray
sleep 1
         systemctl start xray
else
        echo [$LOGTIME] 未发现Xray更新...
fi
}

update_status()
    {
        status_ver=$(wget -qO- --no-check-certificate https://api.github.com/repos/cokemine/ServerStatus-goclient/releases/latest | grep 'tag_name' |  cut -d\" -f4 | sed s/release-//g | sed s/v//g)
        l_status_ver=$(cat /usr/local/bin/status_ver)        
        if [ -n "$l_status_ver" ] && [ "$status_ver" != "$l_status_ver" ]; then 
        echo [$LOGTIME] 发现ServerStatus新版本 ${status_ver}
        systemctl start status
        echo [$LOGTIME] 正在安装ServerStatus v${status_ver}...
        wget --no-check-certificate -qO- "https://github.com/cokemine/ServerStatus-goclient/releases/download/v${status_ver}/status-client_linux_${status_bit}.tar.gz" -O '/usr/local/sh/status.tar.gz'
        mkdir -p /tmp/status/
        tar -xzvf /usr/local/sh/status.tar.gz -C /tmp/status/ >/dev/null 2>&1
        echo ${status_ver} > /usr/local/bin/status_ver
        mv /tmp/status/status-client /usr/local/bin/status-client        
        chmod 755 /usr/local/bin/status-client
        rm /usr/local/sh/status.tar.gz
        rm -r /tmp/status/ 

sleep 1
         systemctl stop status
else
        echo [$LOGTIME] 未发现ServerStatus更新...
fi
}

update_all()
    {
        update_aria2
        #update_xray
        update_status
        update_rclone
        update_alistp
        apt-get update -y && apt-get upgrade -y 
        apt-get autoclean -y
        apt-get clean -y
        apt-get autoremove -y
        dpkg -l |grep ^rc|awk '{print $2}' |xargs dpkg -P
}

if [ $# -ge 1 ];
then
while [ $# -ge 1 ]; do
    case $1 in
        0|install_all) 
            install_all
            shift
            ;;
        1|install_aria2) 
            install_aria2
            shift
            ;;
        2|install_rclone) 
            install_rclone
            shift
            ;;
        3|install_xray) 
            install_xray
            shift
            ;;
        4|install_status) 
            install_status
            shift
            ;;
        5|install_alistp) 
            install_alistp
            shift
            ;;
        6|remove_all) 
            remove_all
            shift
            ;;
        7|remove_aria2) 
            remove_aria2
            shift
            ;;
        8|remove_rclone) 
            remove_rclone
            shift
            ;;
        9|remove_xray) 
            remove_xray
            shift
            ;;
        10|remove_status) 
            remove_status
            shift
            ;;
        11|remove_alistp) 
            remove_alistp
            shift
            ;;
        12|update_all) 
            update_all
            shift
            ;;
        13|update_aria2) 
            update_aria2
            shift
            ;;
        14|update_xray) 
            update_xray
            shift
            ;;
        15|update_status) 
            update_status
            shift
            ;;
        16|update_rclone) 
            update_rclone
            shift
            ;;
        17|update_alistp) 
            update_alistp
            shift
            ;;
        *)
            break;
            ;;                    
    esac
done
else
echo && echo " 
————————————————————————
0 全部安装
1 安装 Aria2
2 安装 Rclone
3 安装 Xray
4 安装 ServerStatus
5 安装 Alist-Proxy
————————————————————————
6 全部卸载
7 卸载 Aria2
8 卸载 Rclone
9 卸载 Xray
10 卸载 ServerStatus
11 卸载 Alist-Proxy
————————————————————————
12 全部更新
13 更新 Aria2
14 更新 Xray
15 更新 ServerStatus
16 更新 Rclone
17 更新 Alist-Proxy
————————————————————————
15 开启 BBR
————————————————————————" && echo

read -p "请输入数字 [0-17]:" num     
    case $num in
        0|install_all) 
            install_all
            shift
            ;;
        1|install_aria2) 
            install_aria2
            shift
            ;;
        2|install_rclone) 
            install_rclone
            shift
            ;;
        3|install_xray) 
            install_xray
            shift
            ;;
        4|install_status) 
            install_status
            shift
            ;;
        5|install_alistp) 
            install_alistp
            shift
            ;;
        6|remove_all) 
            remove_all
            shift
            ;;
        7|remove_aria2) 
            remove_aria2
            shift
            ;;
        8|remove_rclone) 
            remove_rclone
            shift
            ;;
        9|remove_xray) 
            remove_xray
            shift
            ;;
        10|remove_status) 
            remove_status
            shift
            ;;
        11|remove_alistp) 
            remove_alistp
            shift
            ;;
        12|update_all) 
            update_all
            shift
            ;;
        13|update_aria2) 
            update_aria2
            shift
            ;;
        14|update_xray) 
            update_xray
            shift
            ;;
        15|update_status) 
            update_status
            shift
            ;;
        16|update_rclone) 
            update_rclone
            shift
            ;;
        17|update_alistp) 
            update_alistp
            shift
            ;;
        *)
            break;
            ;;                    
    esac
fi